
public class EvenNumbers
{
	public static void main(String[] args)
	{
		
		int n=20;
		System.out.println("even numbers from 1 to n are:");
		for (int i=1;i<=n;i++)
		{
			if(i%2==0)
			{
				System.out.println(i+"");
			}
		}
		
	}
	
	

}
