
public class Rectangle
{
	
    public int area;
    public int length, breadth;
    
    public Rectangle() 
    {
    	
    }
	public Rectangle(int x, int y, int length, int breadth)
	{
		this.length = length;
		this.breadth = breadth;
	}
    
	public void printArea()
	{
		area=length*breadth;
		System.out.println("area of rectangle:"+area);
	}
	
	public void PrintRectangle()
	{
		System.out.println("length of rectangle is:"+length);
		System.out.println("length of rectangle is:"+breadth);
		
		
	}
}

  
  
	
	
