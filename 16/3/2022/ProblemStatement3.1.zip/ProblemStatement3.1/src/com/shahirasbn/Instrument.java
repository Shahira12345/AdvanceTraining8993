package com.shahirasbn;

public abstract class Instrument 
{

	public abstract void play();
	
}
